create database SupermecadorOnline;
use SupermecadorOnline;
create table Cliente(
	IdCliente int(11) Primary key auto_increment,
	Nome char(30),
	Email char(40) unique,
	TipoPessoa enum('CPF, CNPJ')
);

#######__ENDEREÇO REFERENCIA A TABELA CLIENTE______######
create table Endereco(
	Id_Endereco int(11) not null Primary key,
	Rua char(30),
	Bairro char (20),
	Numero int(11),
	Cidade char(20),
	FOREIGN KEY (Id_Endereco) REFERENCES Cliente(IdCliente)
);

#######__CONTATO REFERENCIA A TABELA CLIENTE______######
create table Contato(
	Id_Contato int(10),
	Telefone enum ('fixo,movel'),
	FOREIGN KEY (Id_Contato) REFERENCES Cliente(IdCliente)
);

#######__PRODUTO_____######
create table Produto(
	idProduto int (10) not null Primary key,
	Nome char(10),
	Descricao char(20),
	QrdProduto int(10)
);

#######__PEDIDO REFERENCIA A TABELA CLIENTE____############
create table Pedido(
	idPedido int(10) NOT NULL Primary key,
	Id_Cliente int (11),
	id_Produto int (10),
	QtdPedido int(10),
	ValorPedido int(100),
	FOREIGN KEY (id_Cliente) REFERENCES Cliente(IdCliente),
	FOREIGN KEY (id_Produto) REFERENCES Produto(idProduto)
);
######__PAGAMENTO REFERENCIA A TABELA CLIENTE E PEDIDO__#####
create table Pagamento (
	IdPagamento int(10) NOT NULL Primary key,
	Id_Pedido int (10),
	Id_Cliente int(11),
	valorPagamento int(10),
	TipoPagamento int(10),
	FOREIGN KEY (Id_Pedido) REFERENCES Pedido(idPedido),
	FOREIGN KEY (Id_Cliente) REFERENCES Cliente(IdCliente)
);
#######__PAGAMENTO ONLINE REFERENCIA A TABELA CLIENTE E PAGAMENTO______######
create table PagamentoOnline(
	Id_Pagamento int(10),
	NumeroCartao int(16),
	Bandeira char(10),
	DataValidade int(4),
	CodigoCartao int(3),
	FOREIGN KEY (Id_Pagamento) REFERENCES Pagamento(IdPagamento)
);

######__ENTREGA REFERENCIA TABELA PEDIDO____##############
create table Entrega(
	IdEntrega int(11) NOT NULL Primary key,
	Id_Pedido int (10),
	TipoEntrega char(10),
	StatusEntrega char(10),
	FOREIGN KEY (Id_Pedido) REFERENCES Pedido(idPedido)
);
#######__AGENDAMENTO REFERENCIA A TABELA PEDIDO______######
create table Agendamento(
	Id_Agendamento int(10),
	dataAgendamento datetime,
	FOREIGN KEY (Id_Agendamento) REFERENCES Pedido(idPedido)
	
);

#######__ESTOQUE REFERENCIA A TABELA PEDIDO______######
create table Estoque(
	IdEstoque int(10) Primary key auto_increment,
	Qtd int(10),
	id_Produto int(10),
	FOREIGN KEY (id_Produto) REFERENCES Produto(idProduto)
);
